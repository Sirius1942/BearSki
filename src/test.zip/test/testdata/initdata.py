
#测试项目执行初始化数据
def initData():
    print("in initData")
def clear():
    print("in initData clear")
